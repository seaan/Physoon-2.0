/* PHYSOON 2.0 */
/* Authors:
* Sean Widmier, Tyrell Jamison, Colin Oberthur, Lorraine Rosello
*/
/* DEBUGGING */
//#define DEBUG_TIMEINT
#define DEBUG_GEIGERINT
#define DEBUG_TEMP


/* Includes */
#include <asf.h>
#include "drivers/driver.h" //Includes geiger, led, data, altitude, temperature, pressure.
#include <util/atomic.h>
#include <inttypes.h>

/* Global Variable Declarations */
volatile uint8_t time = 0; //volatile int for time that indicates the variable will be modified inside an interrupt, time is in seconds.
volatile uint16_t ABG_geiger = 0;
volatile uint16_t BG_geiger = 0;
volatile uint8_t test = 1;
uint16_t delayTime = 0;
uint8_t time1 = 2;
StringRing *gps = NULL;


extern char latitude [100];
extern char longitude [100];
extern char satNumber [100];
extern char readAlt [100];
extern int16_t gpsSpeed;




//SMOOTHING DEFINITIONS
int16_t alt;
int16_t smoothedAlt;
int16_t lastSmoothedAlt;
float alpha = 0.36;
//FLIGHT STATE DEFINITIONS
int16_t groundAlt;
uint8_t flightState;
int16_t currentAltitude;
int16_t altcheck;//GLOBAL
int16_t speedCompensationConstant;
int32_t pressure = 0;
MS5607 pressure_sensor;
uint8_t angle;
int16_t eepromData;
int16_t buff; //For reading saved telemetry from eeprom
uint16_t packetCount;
uint16_t delayTime;
uint16_t commandCount;
uint16_t commandTime;
extern int32_t msPressure;


/* Function Prototypes */


/*******************************************************************************************/
										/* Main method */
int main (void){
	board_init();
	sysclk_init(); //Initializes the system clock to 32MHz, also turns off all peripheral clocks.
	data_Init();
	
	twi_options_t m_options = {
		.speed = 400000,
		.speed_reg = TWI_BAUD(32000000, 400000),
	};
	
	sysclk_enable_peripheral_clock(&TWIE);
	twi_master_init(&TWIE, &m_options);
	twi_master_enable(&TWIE);
	
	//delay_ms(2000);
	//printf("Hi67585888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888");
	//init_imu();
	//delay_ms(2000);
	//printf("Hi8796666666666666666666666666666666666666666666666666666666666666666666666666666699999");
	
	//spi_init();
	
	//sysclk_enable_peripheral_clock(&TCE0); //LED timer counter, needs to be changed.
	//sysclk_enable_peripheral_clock(&SPIC); //SPI init for pressure sensor.
	
	
	pressure_sensor.ss_pin = IOPORT_CREATE_PIN(PORTC, 4);	//Assign the correct slave select pins to pressure sensors
	spi_init(&SPIC, &PORTC);	//Initialize the SPI interface
	ioport_configure_pin(pressure_sensor.ss_pin, IOPORT_DIR_OUTPUT || IOPORT_INIT_HIGH);
	pressure_init(&pressure_sensor);	//Initialize the pressure sensor (gets the calibration constants)
	
	
	//sysclk_enable_module(SYSCLK_PORT_E, SYSCLK_HIRES); //LED timer counter, again needs to be changed.
	
	//tc_enable(&TCD0);
	
	
	
	Enable_global_interrupt();
	//TCD0.INTCTRLA = TC_OVFINTLVL_HI_gc; //Enable interrupts using the LED timer counter.
	
	PORTA.PIN2CTRL = PORT_OPC_PULLUP_gc | PORT_ISC_FALLING_gc; //Enable interrupts for porta
	PORTA.PIN3CTRL = PORT_OPC_PULLUP_gc | PORT_ISC_FALLING_gc;
	PORTA.INT0MASK = PIN2_bm; //some masking stuff that should probably help pin interrupts work
	PORTA.INT1MASK = PIN3_bm;
	PORTA.INTCTRL = PORT_INT0LVL_LO_gc | PORT_INT1LVL_LO_gc; //enable porta interrupts low level for interrupt0
	
	PMIC.CTRL = PMIC_HILVLEN_bm | PMIC_LOLVLEN_bm; //Enable high level interrupts.
	
	//tc_set_overflow_interrupt_callback(&TCE0, *yes());
	
	
	
	gps = StringRingCreate(8, 239, true);
	if(gps == NULL)
	{
		printf("%s\n", "OUT OF MEMORY");
		//return -1;
	}
	
	
	while(1)
	{
		//parseGPS();
		//updateAltitude();
		//printf("%s,%s,%s,%s,%i\n",latitude,longitude,readAlt,satNumber,gpsSpeed,pressure);
		sendTelemetry();
		delay_ms(1000);
	}
	/* Peripheral Clock Initializations */
	//sysclk_enable_peripheral_clock(&ADCA); //USART comms clock init for SD reader.
	
	//sysclk_enable_peripheral_clock(&USARTC0);//If this fixes it imma shit myself it didnt my underwar is speared for another day
	//sysclk_enable_peripheral_clock(&TCE0); //LED timer counter, needs to be changed.
	//sysclk_enable_peripheral_clock(&SPIC); //SPI init for pressure sensor.
	
	//sysclk_enable_module(SYSCLK_PORT_E, SYSCLK_HIRES); //LED timer counter, again needs to be changed.
	//sysclk_enable_module(SYSCLK_PORT_C, PR_SPI_bm);
	
	

	//ADCinit();
	

	
	//Allows the PORTE timer counter to be used for the main flight code things
	/*PORTE.DIR = 0xFF;
	TCE0.CTRLA = 0b00000111;
	TCE0.PER = 31249; //7688;
	Enable_global_interrupt(); //Exactly what it says
	TCE0.INTCTRLA = TC_OVFINTLVL_LO_gc; // Enable interrupts for this timer counter
	PMIC.CTRL = PMIC_LOLVLEN_bm; // Enable all low-level interrupts, including this
	
	/* More inits */
	
	//PORTA.DIR |= 0b00001100;
	

	
	//TCE0.INTCTRLA = TC_OVFINTLVL_HI_gc; //Enable interrupts using the LED timer counter.
	//LOOK THIS UP:
	/*
	PORTA.PIN2CTRL = PORT_OPC_PULLUP_gc | PORT_ISC_FALLING_gc; //Enable interrupts for portd, pin0 geiger counter for falling.
	PORTA.PIN3CTRL = PORT_OPC_PULLUP_gc | PORT_ISC_FALLING_gc;
	PORTA.INT0MASK = PIN0_bm; //some masking stuff that should probably help pin0 interrupt0 work
	PORTA.INT1MASK = PIN1_bm;
	PORTA.INTCTRL = PORT_INT0LVL_LO_gc | PORT_INT1LVL_LO_gc; //enable portd interrupts low level for interrupt0
	
	PORTA.PIN0CTRL = PORT_OPC_PULLUP_gc | PORT_ISC_FALLING_gc; //Enable interrupts for portc, pin0 geiger counter for both rising and falling.
	PORTA.INT0MASK = PIN0_bm; //some masking stuff that should probably help pin0 interrupt0 work
	PORTA.INTCTRL = PORT_INT0LVL_LO_gc; //enable portc interrupts low level for interrupt0
	
	PMIC.CTRL = PMIC_HILVLEN_bm | PMIC_LOLVLEN_bm; //Enable high level interrupts. 
	*/

	blinkLED();
	 
	 while(1){
		 
	 }
	 
	//delay_ms(500);
	delay_ms(500);
	printf("Setup finished\n");
	//spi_init();
	
	//printf("%u\n", time1);
	
	//printf("test2\n");
	/* Insert application code here, after the board has been initialized. */
}

ISR(PORTA_INT0_vect){ //Every time alpha geiger sends us a ping, throw this interrupt 
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
		printf("alpha!\n");
		ABG_geiger++; //advance the count for this counter by one.
		pulseLED();
	}
}

ISR(PORTA_INT1_vect){ //Every time beta geiger sends us a ping, throw this interrupt
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
		printf("beta!\n");
		BG_geiger++;
		pulseLED();
	}
}
