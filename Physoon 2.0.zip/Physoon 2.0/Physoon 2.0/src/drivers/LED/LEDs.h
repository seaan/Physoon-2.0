/*
 * LEDs.h
 *
 * Created: 4/25/2017 1:36:40 PM
 *  Author: Lorraine Rosello, Tyrell Jemison, Tommy Tran
 */ 


#ifndef LEDS_H_
#define LEDS_H_
void blinkLED(void);
void pulseLED(void);



#endif /* LEDS_H_ */