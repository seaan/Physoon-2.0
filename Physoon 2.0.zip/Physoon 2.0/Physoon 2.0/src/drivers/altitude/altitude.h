/*
 * altitude.h
 *
 * Created: 11/8/2016 8:23:48 PM
 *  Author: swidmier
 */ 
#include <asf.h>

#ifndef ALTITUDE_H_
#define ALTITUDE_H_

float getAltitude(float temperature, uint32_t inputpressure);



#endif /* ALTITUDE_H_ */