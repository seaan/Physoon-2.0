/*
 * data.c
 *
 * Class to hold geiger counter functions, each of which collects data from their respective counters.
 *
 */ 
#include "drivers/driver.h"
#include "config/conf_usart_serial.h"
#include <string.h>
#include <stdio.h>
/*********************************************************************************/
							/* DATA Methods */
void data_Init(void){
	sysclk_enable_peripheral_clock(&USARTD0);
	static usart_serial_options_t usart_options = {
		.baudrate = 9600,
		.charlength = USART_CHSIZE_8BIT_gc,
		.paritytype = USART_PMODE_DISABLED_gc,
		.stopbits = true
	};
	stdio_serial_init(&USARTD0, &usart_options); //ASF function that initializes the UART peripheral
}
void saveData(uint32_t timestamp, uint16_t alpha_geiger, uint16_t beta_geiger, float altitude){ //this shit is justa complete guess right now lol
	// From Daniel: 
	// using buffer(array) to store each series of readings as string characters (string longer than needed for safety)
	//printf("%i, %i, %i, %i, %.2f\n", timestamp, alpha_geiger, beta_geiger, gamma_geiger, altitude);
	uint8_t buffer[100] = {0};

	//sprintf used because printf was already used?
	uint32_t fixedAlt = (uint32_t)(altitude*100);
	sprintf(buffer, "%lu, %u, %u, %u, %lu\n", timestamp, alpha_geiger, beta_geiger, fixedAlt);
	//UART_Comms_Init();
	printf(buffer);
	//data_Init();
	//usart_serial_write_packet(&USARTF0, buffer,strlen(buffer));
}












#include <asf.h>
#include <string.h>
#include <nvm.h>
#include <math.h>
#include "drivers/driver.h"

extern uint16_t packetCount;
extern int16_t currentAltitude;
extern int32_t msPressure;
extern uint32_t msTemp;
extern char latitude [100];
extern char longitude [100];
extern char satNumber [100];
extern char readAlt [100];
extern char kphSpeed [100];
extern int16_t gpsSpeed;
extern uint16_t commandTime;
extern uint16_t commandCount;
extern uint8_t flightState;
extern mpu9250_data_t mpuData;

void sendTelemetry(void)
{
	packetCount++;
	//adcRead();
	//printf("Hello");
	//delay_ms(1000);
	//updateIMUData();
	//printf("Goodbye");
	updateAltitude();
	parseGPS();
	//printf("%u,%i,%li,%lu,%s,%s,%s,%s,%i,%i,%i,%i\n",packetCount,currentAltitude,msPressure,msTemp,latitude,longitude,readAlt,satNumber,gpsSpeed,mpuData.acc_x,mpuData.acc_y,mpuData.acc_z);
	printf("%u,%i,%li,%lu,%s,%s,%s,%s,%i\n",packetCount,currentAltitude,msPressure,msTemp,latitude,longitude,readAlt,satNumber,gpsSpeed);
}
