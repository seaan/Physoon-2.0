/*
 * Temperature.h
 *
 * Created: 4/20/2017 7:05:24 PM
 *  Author: Lorraine Rosello, Tyrell Jemison, Tommy Tran
 */ 


#ifndef TEMPERATURE_H_
#define TEMPERATURE_H_

 void ADCinit(void);
 float getTemperature(void);


#endif /* TEMPERATURE_H_ */