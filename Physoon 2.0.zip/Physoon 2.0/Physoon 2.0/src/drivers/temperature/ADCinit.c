/*
 * ADCinit.c
 *
 * Created: 4/20/2017 8:00:09 PM
 *  Author: Lorraine Rosello, Tyrell Jemison, Tommy Tran
 */ 
 #include <asf.h>
 #include "drivers/driver.h"
 //include the library for delay_ms
