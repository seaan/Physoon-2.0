/*
 * temperature.h
 *
 * Created: 11/8/2016 8:24:07 PM
 *  Author: swidmier
 */ 
#include <asf.h>

#ifndef TEMPERATURE_H_
#define TEMPERATURE_H_

float getTemperature(void);



#endif /* TEMPERATURE_H_ */