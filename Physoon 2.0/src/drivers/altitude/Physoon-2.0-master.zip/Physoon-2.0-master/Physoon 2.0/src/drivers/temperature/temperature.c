/*
 * geiger_counter.c
 *
 * Class to hold temperature functions to read in temperature from thermistor.
 *
 */ 
#include "drivers/temperature/temperature.h"
#include <asf.h>
/*********************************************************************************/
							/* Temperature Methods */

float getTemperature(void){
	
}